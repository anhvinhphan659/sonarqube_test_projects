#include <iostream>
#include <string>
#include "Reader.h"
#pragma once

bool leapyear(int y);
int DaysOfMonth(int m, int y);
int DaysofYears(int y);
int Daysfrom1(int d, int m, int y);
bool ReturnAfter(int d, int m, int y, int d2, int m2, int y2);
void CorrectDays(int& d, int& m, int& y);
bool readercheck(current c, reader r[], int borrowID);
void Correct(int y);


