#include "Reader.h"
#include "Other.h"
#include "Card.h"

//Kiem tra co phai doc gia khong
bool readercheck(current c, reader r[], int borrowID)
{
	for (int i = 0; i < c.current1; i++)
	{
		if (borrowID == r[i].id)
		{
			return 1;
		}
	}
	return 0;
}

//Nam nhuan
bool leapyear(int y)
{
	if (y % 400 == 0 || (y % 100 != 0 && y % 4 == 0)) return 1;
	return 0;
}

//So ngay trong thang
int DaysOfMonth(int m, int y)
{
	if (m == 2)
	{
		if (leapyear(y))
		{
			return 29;
		}
		return 28;
	}
	else
	{
		switch (m)
		{
		case 4: case 6: case 9: case 11:
			return 30;
		case 1: case 3: case 5: case 7: case 8: case 10: case 12:
			return 31;
		}
	}
}

//So ngay giua cac nam
int DaysofYears(int y)
{
	int days = 0;
	for (int i = 0; i < y; i++)
	{
		if (leapyear(y))
		{
			days = days + 366;
		}
		else
		{
			days = days + 365;
		}
	}
	return days;
}

//So ngay tinh tu dau nam
int Daysfrom1(int d, int m, int y)
{
	int days = d;
	for (int i = 0; i < m; i++)
	{
		days = days + DaysOfMonth(m, y);
	}
	return days;
}

//Kiem tra ngay tra sau ngay muon
bool ReturnAfter(int d, int m, int y, int d2, int m2, int y2)
{
	if (y2 > y) return 1;
	else
	{
		if (m2 > m) return 1;
		else if (m2 = m)
		{
			if (d2 >= d) return 1;
			return 0;
		}
		return 0;
	}
}

//Kiem tra nhap ngay 
void CorrectDays(int& d, int& m, int& y)
{
	while (d > DaysOfMonth(m, y) || d < 1)
	{
		cout << "Hay nhap lai ngay: ";
		cin >> d;
	}
	while (m > 12 || m < 1)
	{
		cout << "Hay nhap lai thang: ";
		cin >> m;
	}
	while (y < 1900)
	{
		cout << "Hay nhap lai nam: ";
		cin >> y;
	}
}


//Kiem tra nhap nam
void Correct(int y)
{
	while (y < 1000 || y > 3000)
	{
		cout << "Hay nhap lai nam: ";
		cin >> y;
	}
}


