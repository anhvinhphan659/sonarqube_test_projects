#include "Reader.h"
#include "Other.h"

//Them doc gia
void addreader(reader a[], current& c)
{
	if (c.current1 == 100) return;
	else {
		cout << endl;
		cout << "------------------------------------------------------------\n";
		cout << endl;
		cout << "                   THEM DOC GIA  \n";
		cout << endl;
		cout << "                   Luu y \n";
		cout << "* Ten rieng viet hoa chu cai dau" << endl;
		cout << "* Nhap ngay, thang, nam cach mot khoang trang " << endl << endl;
		cout << "Nhap ma doc gia (4 so): ";
		do
		{
			cin >> a[c.current1].id;
			if (a[c.current1].id < 1000 || a[c.current1].id > 9999) cout << "Hay nhap lai: ";
			else break;
		} while (1);
		if (readercheck(c, a, a[c.current1].id) == 1)
		{
			cout << "Ban da la doc gia cua thu vien " << endl;
		}
		else
		{
			cout << "Nhap ho ten: ";
			cin.ignore();
			getline(cin, a[c.current1].name);
			cout << "Nhap ngay thang nam sinh: ";
			cin >> a[c.current1].birthday[0] >> a[c.current1].birthday[1] >> a[c.current1].birthday[2];
			CorrectDays(a[c.current1].birthday[0], a[c.current1].birthday[1], a[c.current1].birthday[2]);
			cout << "Nhap gioi tinh (1.Nam / 0.Nu): ";
			do
			{
				cin >> a[c.current1].gender;
			if (a[c.current1].gender != 1 && a[c.current1].gender != 0) cout << "Hay nhap lai: ";
				else break;
			} while (1);
			cout << "Nhap can cuoc cong dan (9 so): ";
			do
			{
				cin >> a[c.current1].socialID;
				if (a[c.current1].socialID.size() < 9 || a[c.current1].socialID.size() > 9) cout << "Hay nhap lai: ";
				else break;
			} while (1);
			cout << "Nhap email: ";
			cin >> a[c.current1].email;
			cout << "Nhap dia chi: ";
			cin.ignore();
			getline(cin, a[c.current1].address);
			cout << "Nhap ngay lap the: ";
			cin >> a[c.current1].date[0] >> a[c.current1].date[1] >> a[c.current1].date[2];
			CorrectDays(a[c.current1].date[0], a[c.current1].date[1], a[c.current1].date[2]);
			c.current1++;
		}
	}
}

//Luu doc gia vao file
void savereader(reader a[], current& c)
{
	ofstream in;
	in.open("reader.txt",ios::out);
	if (in.fail() == false)
	{
		in << c.current1 << "\n";
		for (int i = 0; i < c.current1; i++)
		{
			in << a[i].id;
			in << a[i].name << "-";
			in << a[i].birthday[0] << " ";
			in << a[i].birthday[1] << " ";
			in << a[i].birthday[2] << " ";
			in << a[i].gender << " ";
			in << a[i].socialID << "-";
			in << a[i].email << "-";
			in << a[i].address << "-";
			in << a[i].date[0] << " ";
			in << a[i].date[1] << " ";
			in << a[i].date[2] << "\n";
		}
	}
	in.close();
}

//Tai doc gia tu file
void loadreader(reader a[], current& c)
{
	ifstream out;
	out.open("reader.txt", ios::in);
	if (out.fail() == false)
	{
		out >> c.current1;
		for (int i = 0; i < c.current1; i++)
		{
			out >> a[i].id;
			getline(out,a[i].name, '-');
			out >> a[i].birthday[0];
			out >> a[i].birthday[1];
			out >> a[i].birthday[2];
			out >> a[i].gender;
			out.seekg(1, ios_base::cur);
			getline(out, a[i].socialID, '-');
			getline(out, a[i].email, '-');
			getline(out, a[i].address, '-');
			out >> a[i].date[0];
			out >> a[i].date[1];
			out >> a[i].date[2];
		}
	}
	out.close();
}

//Xem doc gia
void viewreader(reader a[], current c)
{
	cout << endl;
	cout << "------------------------------------------------------------\n";
	cout << endl;
	cout << "                   DANH SACH DOC GIA\n";
	for (int i = 0; i < c.current1; i++)
	{
		cout << endl;
		cout << "Ma doc gia: ";
		cout << a[i].id << endl;
		cout << "Ho Ten: ";
		cout << a[i].name << endl;
		cout << "Ngay thang nam sinh: ";
		cout << a[i].birthday[0] << "/" << a[i].birthday[1] << "/" << a[i].birthday[2] << endl;
		cout << "Gioi tinh: ";
		if (a[i].gender == 1) { cout << "nam" << endl; }
		else if (a[i].gender == 0) { cout << "nu" << endl; }
		cout << "Can cuoc cong dan: ";
		cout << a[i].socialID << endl;
		cout << "Email: ";
		cout << a[i].email << endl;
		cout << "Dia chi: ";
		cout << a[i].address << endl;
		cout << "Ngay lap the: ";
		cout << a[i].date[0] << "/" << a[i].date[1] << "/" << a[i].date[2] << endl;
		cout << "Ngay het han the: ";
		cout << a[i].date[0] << "/" << a[i].date[1] << "/" << a[i].date[2] + 4 << endl;
		cout << endl;
		cout << "------------------------------------------------------------\n";
	}
}

//Sua doc gia
void fixreader(reader a[], current c)
{
	int fixID;
	cout << "------------------------------------------------------------\n";
	cout << endl;
	cout << "                   SUA THONG TIN DOC GIA  \n";
	cout << endl;
	cout << "Nhap ma doc gia cua nguoi can sua: ";
	cin >> fixID;
	for (int i = 0; i < c.current1; i++)
	{
		if (a[i].id == fixID)
		{
			int choice;
			do
			{
				cout << "Chon thong tin muon chinh sua: \n";
				cout << "1. Ma doc gia \n";
				cout << "2. Ho Ten \n";
				cout << "3. Ngay thang nam sinh\n";
				cout << "4. Gioi tinh \n";
				cout << "5. Can cuoc cong dan \n";
				cout << "6. Email \n";
				cout << "7. Dia Chi\n";
				cout << "8. Ngay lap the\n";
				cout << "0. Thoat \n";
				cout << endl;
				cout << "Lua chon cua ban: ";
				cin >> choice;
				cout << endl;

				switch (choice)
				{
				case 1:
					cout << "Sua ma doc gia (4 so): ";
					do
					{
						cin >> a[i].id;
						if (a[i].id < 1000 || a[i].id > 9999) cout << "Hay nhap lai: ";
						else break;
					} while (1);
					break;
				case 2:
					cout << "(* Ten rieng viet hoa chu cai dau *)" << endl << endl;
					cout << "Sua ho ten: ";
					cin.ignore();
					getline(cin, a[i].name);
					break;
				case 3:
					cout << "(* Nhap ngay, thang, nam cach mot khoang trang *)" << endl << endl;
					cout << "Sua ngay thang nam sinh moi: ";
					cin >> a[i].birthday[0] >> a[i].birthday[1] >> a[i].birthday[2];
					CorrectDays(a[i].birthday[0], a[i].birthday[1], a[i].birthday[2]);
					break;
				case 4:
					cout << "Sua gioi tinh (1.Nam / 0.Nu): ";
					cin >> a[i].gender;
					break;
				case 5:
					cout << "Sua can cuoc cong dan (9 so): ";
					do
					{
						cin >> a[i].socialID;
						if (a[i].socialID.size() < 9 || a[i].socialID.size() > 9) cout << "Hay nhap lai: ";
						else break;
					} while (1);
					break;
				case 6:
					cout << "Sua email: ";
					cin >> a[i].email;
					break;
				case 7:
					cout << "(* Ten rieng viet hoa chu cai dau *)" << endl << endl;
					cout << "Sua dia chi: ";
					cin.ignore();
					getline(cin, a[i].address);
					break;
				case 8:
					cout << "(* Nhap ngay, thang, nam cach mot khoang trang *)" << endl << endl;
					cout << "Sua ngay lap the: ";
					cin >> a[i].date[0] >> a[i].date[1] >> a[i].date[2];
					CorrectDays(a[i].date[0], a[i].date[1], a[i].date[2]);
					break;
				}
			} while (choice != 0);

			return;
		}
	}
	cout << "Khong tim thay doc gia nay trong thu vien!" << endl;
}

//Xoa thong tin doc gia
void erasereader(reader a[], current& c)
{
	int eraseID;
	cout << "------------------------------------------------------------\n";
	cout << endl;
	cout << "                   XOA THONG TIN DOC GIA  \n";
	cout << endl;
	cout << "Nhap ma doc gia cua nguoi can xoa: ";
	cin >> eraseID;
	for (int i = 0; i < c.current1; i++)
	{
		if (eraseID == a[i].id)
		{
			a[i].id = a[i + 1].id;
			a[i].name = a[i + 1].name;
			a[i].birthday[0] = a[i + 1].birthday[0];
			a[i].birthday[1] = a[i + 1].birthday[1];
			a[i].birthday[2] = a[i + 1].birthday[2];
			a[i].gender = a[i + 1].gender;
			a[i].socialID = a[i + 1].socialID;
			a[i].address = a[i + 1].address;
			a[i].date[0] = a[i + 1].date[0];
			a[i].date[1] = a[i + 1].date[1];
			a[i].date[2] = a[i + 1].date[2];
			a[i].email = a[i + 1].email;
			c.current1--;
			return;
		}
	}
	cout << "Khong tim thay doc gia nay trong thu vien!" << endl;
}

//Tim doc gia theo CMND
void findsocialID(reader a[], current c)
{
	string findsocialID;
	cout << "------------------------------------------------------------\n";
	cout << endl;
	cout << "                   TIM DOC GIA THEO CMND  \n";
	cout << endl;
	cout << "Nhap CMND/CCCD cua nguoi can tim: ";
	cin >> findsocialID;
	for (int i = 0; i < c.current1; i++)
	{
		if (findsocialID == a[i].socialID)
		{
			cout << endl;
			cout << "Ma doc gia: ";
			cout << a[i].id << endl;
			cout << "Ho Ten: ";
			cout << a[i].name << endl;
			cout << "Ngay thang nam sinh: ";
			cout << a[i].birthday[0] << "/" << a[i].birthday[1] << "/" << a[i].birthday[2] << endl;
			cout << "Gioi tinh: ";
			if (a[i].gender) { cout << "nam" << endl; }
			else { cout << "nu" << endl; }
			cout << "Can cuoc cong dan: ";
			cout << a[i].socialID << endl;
			cout << "Email: ";
			cout << a[i].email << endl;
			cout << "Dia chi: ";
			cout << a[i].address << endl;
			cout << "Ngay lap the: ";
			cout << a[i].date[0] << "/" << a[i].date[1] << "/" << a[i].date[2] << endl;
			cout << "Ngay het han the: ";
			cout << a[i].date[0] << "/" << a[i].date[1] << "/" << a[i].date[2] + 4 << endl;
			cout << endl;
			return;
		}
	}
	cout << "Khong tim thay doc gia nay trong thu vien." << endl << endl;
}

//Tim doc gia theo ten
void findreaderName(reader a[], current c)
{
	string findname;
	cout << "------------------------------------------------------------\n";
	cout << endl;
	cout << "                   TIM DOC GIA THEO TEN  \n";
	cout << endl;
	cout << "(* Ten rieng viet hoa chu cai dau *)" << endl << endl;
	cout << "Nhap ten nguoi can tim: ";
	cin.ignore();
	getline(cin, findname);
	for (int i = 0; i < c.current1; i++)
	{
		if (findname == a[i].name)
		{
			cout << endl;
			cout << "Ma doc gia: ";
			cout << a[i].id << endl;
			cout << "Ho Ten: ";
			cout << a[i].name << endl;
			cout << "Ngay thang nam sinh: ";
			cout << a[i].birthday[0] << "/" << a[i].birthday[1] << "/" << a[i].birthday[2] << endl;
			cout << "Gioi tinh: ";
			if (a[i].gender) { cout << "nam" << endl; }
			else { cout << "nu" << endl; }
			cout << "Can cuoc cong dan: ";
			cout << a[i].socialID << endl;
			cout << "Email: ";
			cout << a[i].email << endl;
			cout << "Dia chi: ";
			cout << a[i].address << endl;
			cout << "Ngay lap the: ";
			cout << a[i].date[0] << "/" << a[i].date[1] << "/" << a[i].date[2] << endl;
			cout << "Ngay het han the: ";
			cout << a[i].date[0] << "/" << a[i].date[1] << "/" << a[i].date[2] + 4 << endl;
			cout << endl;
			return;
		}
	}
	cout << "Khong tim thay doc gia nay trong thu vien." << endl << endl;
}

