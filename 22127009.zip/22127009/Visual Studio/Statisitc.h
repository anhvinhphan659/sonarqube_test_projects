
#include "Reader.h"
#include "Book.h"
#include "Card.h"

//Thong ke
void bookquantity(book b[], current c);
void typequantity(book b[], current c);
void genderquantity(reader a[], current c, int& nam, int& nu);
void genderstatistic(reader a[], current c, int& nam, int& nu);
void borrowed(card a, current c);
void overdue(reader a[], card x[], current c);
void readerquantity(current c);