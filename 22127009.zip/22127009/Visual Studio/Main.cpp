#include "Reader.h"
#include "Book.h"
#include "Card.h"
#include "Statisitc.h"
#include "User.h"

int main()
{
	//Khai bao
	user u;
	int nam = 0, nu = 0;
	reader a[100];
	book b[100];
	current c;
	card x[100], y;
	int choice;
	loadreader(a, c);
	loadbook(b, c);
	loadcard(x, y, c);

	//Dang nhap
	signin(u);

	//Menu
	do
	{
		cout << endl;
		cout << "   /\\_/\\=======================================/\\_/\\  \n";
		cout << "  ( o.o )          THU VIEN VNU-HCMUS         ( o.o ) \n";
		cout << "   > ^ <=======================================> ^ < \n";
		cout << "   |                                               | \n";
		cout << "   |     Chon mot trong nhung chuc nang sau:       |\n";
		cout << "   |     1. Quan ly doc gia                        |\n";
		cout << "   |     2. Quan li sach                           | \n";
		cout << "   |     3. Phieu muon sach                        |\n";
		cout << "   |     4. Phieu tra sach                         |\n";
		cout << "   |     5. Thong ke                               |\n";
		cout << "   |     0. Thoat                                  |\n";
		cout << "   |_______________________________________________| \n";
		cout << endl;
		cout << " Lua chon cua ban: ";
		cin >> choice;
		system("CLS");
		switch (choice)
		{
			char choice2;
		case 1:
			do
			{
				cout << "                         (\\-----/)" << endl;
				cout << "                          ) . . (" << endl;
				cout << "___________________, --._(___Y___)_, --.____________________ " << endl;
				cout << "                   `- -'           `- -'" << endl;
				cout << "============================================================" << endl;
				cout << endl;
				cout << "                   QUAN LY DOC GIA  \n";
				cout << endl;
				cout << "Chon mot trong nhung chuc nang sau: \n";
				cout << " a. Xem danh sach doc gia trong thu vien \n";
				cout << " b. Them doc gia \n";
				cout << " c. Chinh sua thong tin doc gia \n";
				cout << " d. Xoa thong tin doc gia \n";
				cout << " e. Tim kiem doc gia theo CMND/CCCD \n";
				cout << " f. Tim kiem doc gia theo ho ten \n";
				cout << " x. Thoat \n";
				cout << endl;
				cout << " Lua chon cua ban: ";
				cin >> choice2;
				switch (choice2)
				{
				case 'a':
					viewreader(a, c);
					break;
				case 'b':
					addreader(a, c);
					break;
				case 'c':
					fixreader(a, c);
					break;
				case 'd':
					erasereader(a, c);
					savereader(a, c);
					break;
				case 'e':
					findsocialID(a, c);
					break;
				case 'f':
					findreaderName(a, c);
					break;
				default:
					break;
				}
				savereader(a, c);
				system("PAUSE");
				system("CLS");
			} while (choice2 != 'x');
			
			break;

		case 2:
			do
			{
				cout << "                         (\\-----/)" << endl;
				cout << "                          ) . . (" << endl;
				cout << "___________________, --._(___Y___)_, --.____________________ " << endl;
				cout << "                   `- -'           `- -'" << endl;
				cout << "============================================================" << endl;
				cout << endl;
				cout << "                   QUAN LY SACH \n";
				cout << endl;
				cout << "Chon mot trong nhung chuc nang sau: \n";
				cout << " a. Xem danh sach cac sach trong thu vien \n";
				cout << " b. Them sach \n";
				cout << " c. Chinh sua thong tin mot quyen sach \n";
				cout << " d. Xoa thong tin sach \n";
				cout << " e. Tim kiem sach theo ISBN \n";
				cout << " f. Tim kiem sach theo ten sach \n";
				cout << " x. Thoat \n";
				cout << endl;
				cout << " Lua chon cua ban: ";
				cin >> choice2;
				switch (choice2)
				{
				case 'a':
					viewbook(b, c);
					break;
				case 'b':
					addbook(b, c);
					break;
				case 'c':
					fixbook(b, c);
					break;
				case 'd':
					erasebook(b, c);
					savebook(b, c);
					break;
				case 'e':
					findISBN(b, c);
					break;
				case 'f':
					findbookname(b, c);
					break;
				default:
					break;
				}
				savebook(b, c);
				system("PAUSE");
				system("CLS");
			} while (choice2 != 'x');
			break;

		case 3:
			cout << "                         (\\-----/)" << endl;
			cout << "                          ) . . (" << endl;
			cout << "___________________, --._(___Y___)_, --.____________________ " << endl;
			cout << "                   `- -'           `- -'" << endl;
			cout << "============================================================" << endl;
			cout << endl;

			bcard(x, b, a, c);
			savecard(x, y, c);
			savebook(b, c);
			system("PAUSE");
			system("CLS");

			break;

		case 4:
			cout << "                         (\\-----/)" << endl;
			cout << "                          ) . . (" << endl;
			cout << "___________________, --._(___Y___)_, --.____________________ " << endl;
			cout << "                   `- -'           `- -'" << endl;
			cout << "============================================================" << endl;
			cout << endl;

			rcard(x, b, a, c, y);
			savecard(x, y, c);
			savebook(b, c);
			system("PAUSE");
			system("CLS");
			break;

		case 5:
			do
			{
				cout << "                         (\\-----/)" << endl;
				cout << "                          ) . . (" << endl;
				cout << "___________________, --._(___Y___)_, --.____________________ " << endl;
				cout << "                   `- -'           `- -'" << endl;
				cout << "============================================================" << endl;
				cout << endl;
				cout << "                   THONG KE \n";
				cout << " a. Thong ke so luong sach trong thu vien \n";
				cout << " b. Thong ke so luong sach theo the loai \n";
				cout << " c. Thong ke so luong doc gia trong thu vien \n";
				cout << " d. Thong ke so luong doc gia theo gioi tinh \n";
				cout << " e. Thong ke so luong sach dang duoc muon \n";
				cout << " f. Thong ke so luong doc gia tre han \n";
				cout << " x. Thoat \n";
				cout << endl;
				cout << " Lua chon cua ban: ";
				cin >> choice2;
				switch (choice2)
				{
				case 'a':
					bookquantity(b, c);
					break;
				case 'b':
					typequantity(b,c);
					break;
				case 'c':
					readerquantity(c);
					break;
				case 'd':
					genderstatistic(a, c, nam, nu);
					break;
				case 'e':
					borrowed(y, c);
					break;
				case 'f':
					overdue(a, x, c);
					break;
				}
				system("PAUSE");
				system("CLS");
			} while (choice2 != 'x');
			break;

		default:
			break;
		}	
	} while (choice != 0);
	return 0;
}