
#include "Reader.h"
#include "Book.h" 
#include "Other.h"
#pragma once

struct card
{
	int borrowlist;
	int id2, fee = 0;
	int expreturndate[3], borrowdate[3], returndate[3];
	int rcard = 0;
};

int DelayDays(int d, int m, int y, int d2, int m2, int y2);
bool bcardcheck(current c, card a[], string borrowID);
void bcard(card a[], book b[], reader r[], current& c);
void rcard(card a[], book b[], reader r[], current& c, card& x);
void savecard(card a[], card x, current& c);
void loadcard(card a[], card x, current& c);
