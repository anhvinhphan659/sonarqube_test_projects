#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <Windows.h>
#pragma once
using namespace std;

struct current
{
	int current1 = 3, current2 = 3, current3 = 1;
};

struct reader
{
	string name, email, address, socialID;
	int birthday[3];
	int gender, id;
	int date[3];
};

void addreader(reader a[], current& c);
void viewreader(reader a[], current c);
void fixreader(reader a[], current c);
void erasereader(reader a[], current& c);
void findsocialID(reader a[], current c);
void findreaderName(reader a[], current c);
void savereader(reader a[], current& c);
void loadreader(reader a[], current& c);
