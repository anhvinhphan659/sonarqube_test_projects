#pragma once
#include "Reader.h"

struct user
{
	string username, password;
};

void signin(user a);