#include "Reader.h"
#include "Book.h" 
#include "Other.h"

using namespace std;


//Luu sach vao file
void savebook(book a[], current& c)
{
	ofstream in;
	in.open("book.txt");
	if (in.fail() == false)
	{
		in << c.current2 << "\n";
		for (int i = 0; i < c.current2; i++)
		{
			in << a[i].ISBN;
			in << a[i].bookname << "-";
			in << a[i].author << "-";
			in << a[i].publiccomp << "-";
			in << a[i].publicyear;
			in << a[i].type << "-";
			in << a[i].price << " ";
			in << a[i].quantity;
			in << endl;
		}
	}
	in.close();
}

//Xuat sach tu file
void loadbook(book a[], current& c)
{
	ifstream out;
	out.open("book.txt", ios::in);
	if (out.fail() == false)
	{
		out >> c.current2;
		for (int i = 0; i < c.current2; i++)
		{
			out >> a[i].ISBN;
			getline(out, a[i].bookname, '-');
			getline(out, a[i].author, '-');
			getline(out, a[i].publiccomp, '-');
			out >> a[i].publicyear;
			getline(out, a[i].type, '-');
			out >> a[i].price;
			out >> a[i].quantity;
		}
	}
	out.close();
}

//Them sach
void addbook(book a[], current& c)
{
	if (c.current2 == 100) return;
	cout << "------------------------------------------------------------\n";
	cout << "                   THEM THONG TIN SACH  \n";

	cout << endl;
	cout << "Nhap ma sach ISBN (4 so): ";
	do
	{
		cin >> a[c.current2].ISBN;
		if (a[c.current2].ISBN < 1000 || a[c.current2].ISBN > 9999) cout << "Hay nhap lai: ";
		else break;
	} while (1);
	cout << "Nhap ten sach: ";
	cin.ignore();
	getline(cin, a[c.current2].bookname);
	cout << "Nhap ten tac gia: ";
	getline(cin, a[c.current2].author);
	cout << "Nhap ten nha san xuat: ";
	getline(cin, a[c.current2].publiccomp);
	cout << "Nhap nam san xuat: ";
	cin >> a[c.current2].publicyear;
	Correct(a[c.current2].publicyear);
	cout << " * Gom cac loai: tieu thuyet, giao trinh, thieu nhi, tai lieu, truyen, khoa hoc" << endl;
	cout << "Nhap the loai sach (viet thuong): ";
	cin.ignore();
	getline(cin, a[c.current2].type);
	cout << "Nhap gia sach: ";
	cin >> a[c.current2].price;
	cout << "Nhap so luong sach: ";
	cin >> a[c.current2].quantity;
	c.current2++;
}

//Xem danh sach sach
void viewbook(book a[], current c)
{
	cout << endl;
	cout << "------------------------------------------------------------\n";
	cout << endl;
	cout << "                   DANH SACH SACH\n";
	for (int i = 0; i < c.current2; i++)
	{
		cout << endl;
		cout << "Ma sach (ISBN): " << a[i].ISBN << endl;
		cout << "Ten sach: " << a[i].bookname << endl;;
		cout << "Tac gia: " << a[i].author << endl;;
		cout << "Nha xuat ban: " << a[i].publiccomp << endl;
		cout << "Nam san xuat: " << a[i].publicyear << endl;
		cout << "The loai: " << a[i].type << endl;
		cout << "Gia sach: " << a[i].price  << endl;
		cout << "So luong: " << a[i].quantity << endl;
		cout << endl;
		cout << "------------------------------------------------------------\n";
	}
}


//Sua thong tin sach
void fixbook(book a[], current c)
{
	int fixID;
	cout << "------------------------------------------------------------\n";
	cout << endl;
	cout << "                   SUA THONG TIN SACH  \n";
	cout << endl;
	cout << "Nhap ISBN cua sach can sua: ";
	cin >> fixID;
	cout << endl;
	for (int i = 0; i < c.current2; i++)
	{
		if (a[i].ISBN == fixID)
		{
			int choice;
			do
			{
				cout << "Chon thong tin muon chinh sua: \n";
				cout << "1. Ma sach (ISBN)\n";
				cout << "2. Ten sach\n";
				cout << "3. Tac gia \n";
				cout << "4. Nha xuat ban \n";
				cout << "5. Nam xuat ban \n";
				cout << "6. The loai \n";
				cout << "7. Gia sach\n";
				cout << "8. So luong\n";
				cout << "0. Thoat \n";
				cout << "Lua chon cua ban: ";
				cin >> choice;
				switch (choice)
				{
				case 1:
					cout << "Sua ma sach (4 so): ";
					do
					{
						cin >> a[i].ISBN;
						if (a[i].ISBN < 1000 || a[i].ISBN > 9999) cout << "Hay nhap lai: ";
						else break;
					} while (1);
					break;
				case 2:
					cout << "Sua ten sach: ";
					cin.ignore();
					getline(cin, a[i].bookname);
					break;
				case 3:
					cout << "Sua ten tac gia: ";
					cin.ignore();
					getline(cin, a[i].author);
					break;
				case 4:
					cout << "Sua nha xuat ban: ";
					cin.ignore();
					getline(cin, a[i].publiccomp);
					break;
				case 5:
					cout << "Sua nam xuat ban: ";
					cin >> a[i].publicyear;
					Correct(a[i].publicyear);
					break;
				case 6:
					cout << " * Gom cac loai: tieu thuyet, giao trinh, thieu nhi, tai lieu, truyen, khoa hoc" << endl;
					cout << "Nhap the loai sach (viet thuong): ";
					cin.ignore();
					getline(cin, a[i].type);
					break;
				case 7:
					cout << "Sua gia sach: ";
					cin >> a[i].price ;
					break;
				case 8:
					cout << "Sua so luong sach: ";
					cin >> a[i].quantity;
					break;
				}
			} while (choice != 0);
			return;
		}
	}
	cout << "Khong tim thay sach nay trong thu vien." << endl << endl;
}

//Xoa thong tin sach
void erasebook(book a[], current& c)
{
	int eraseID;
	cout << "------------------------------------------------------------\n";
	cout << endl;
	cout << "                   XOA THONG TIN SACH  \n";
	cout << endl;
	cout << "Nhap ISBN cua sach can xoa (4 so): ";
	cin >> eraseID;
	cout << endl;

	for (int i = 0; i < c.current2; i++)
	{
		if (a[i].ISBN == eraseID)
		{
			a[i].ISBN = a[i + 1].ISBN;
			a[i].bookname = a[i + 1].bookname;
			a[i].author = a[i + 1].author;
			a[i].publiccomp = a[i + 1].publiccomp;
			a[i].publicyear = a[i + 1].publicyear;
			a[i].type = a[i + 1].type;
			a[i].price  = a[i + 1].price;
			a[i].quantity = a[i + 1].quantity;
			c.current2--;
			return;
		}
	}
	cout << "Khong tim thay sach nay trong thu vien." << endl << endl;
}

//Tim sach theo ISBN
void findISBN(book a[], current c)
{
	int findISBN;
	cout << "------------------------------------------------------------\n";
	cout << endl;
	cout << "                   TIM SACH THEO ISBN  \n";
	cout << endl;
	cout << "Nhap ISBN cua sach can tim (4 so): ";
	cin >> findISBN;
	cout << endl;
	for (int i = 0; i < c.current2; i++)
	{
		if (findISBN == a[i].ISBN)
		{
			cout << "Ma sach (ISBN): " << a[i].ISBN << endl;
			cout << "Ten sach: " << a[i].bookname << endl;;
			cout << "Tac gia: " << a[i].author << endl;;
			cout << "Nha xuat ban: " << a[i].publiccomp << endl;
			cout << "Nam san xuat: " << a[i].publicyear << endl;
			cout << "The loai: " << a[i].type << endl;
			cout << "Gia sach: " << a[i].price  << endl;
			cout << "So luong: " << a[i].quantity << endl;
			return;
		}
	}
	cout << "Khong tim thay sach nay trong thu vien." << endl << endl;
}

//Tim sach theo ten
void findbookname(book a[], current c)
{
	string findbookname;
	cout << "------------------------------------------------------------\n";
	cout << endl;
	cout << "                   TIM SACH THEO TEN  \n";
	cout << endl;
	cout << "Nhap ten sach can tim: ";
	cin.ignore();
	getline(cin, findbookname);
	cout << endl;
	for (int i = 0; i < c.current2; i++)
	{
		if (findbookname == a[i].bookname)
		{
			cout << "Ma sach (ISBN): " << a[i].ISBN << endl;
			cout << "Ten sach: " << a[i].bookname << endl;;
			cout << "Tac gia: " << a[i].author << endl;;
			cout << "Nha xuat ban: " << a[i].publiccomp << endl;
			cout << "Nam san xuat: " << a[i].publicyear << endl;
			cout << "The loai: " << a[i].type << endl;
			cout << "Gia sach: " << a[i].price  << endl;
			cout << "So luong: " << a[i].quantity << endl;
			return;
		}
	}
	cout << "Khong tim thay sach nay trong thu vien." << endl << endl;
}
