#include "Reader.h"
#include "Book.h"
#include "Card.h"

//Thong ke so luong sach trong thu vien
void bookquantity(book b[], current c)
{
	int count = 0;
	for (int i = 0; i < c.current2; i++)
	{
		count = count + b[i].quantity;
	}
	cout << "------------------------------------------------------------\n" << endl;
	cout << "                   THONG KE \n" << endl;
	cout << "So sach co trong thu vien: " << count << endl;
}

//Thong ke so luong sach theo the loai
void typequantity(book b[], current c)
{
	int count = 0, count2 = 0, count3 = 0, count4 = 0, count5 = 0, count6 = 0;
	for (int i = 0; i < c.current2; i++)
	{
		if (b[i].type == "tieu thuyet")
		{
			count = count + b[i].quantity;
		}
		if (b[i].type == "truyen")
		{
			count2 = count2 + b[i].quantity;
		}
		if (b[i].type == "khoa hoc")
		{
			count3 = count3 + b[i].quantity;
		}
		if (b[i].type == "thieu nhi")
		{
			count4 = count4 + b[i].quantity;
		}
		if (b[i].type == "tai lieu")
		{
			count5 = count5 + b[i].quantity;
		}
		if (b[i].type == "giao trinh")
		{
			count6 = count6 + b[i].quantity;
		}
	}
	cout << "------------------------------------------------------------\n" << endl;
	cout << "                   THONG KE \n" << endl;
	cout << "Tieu thuyet: " << count << endl;
	cout << endl;
	cout << "Truyen: " << count2 << endl;
	cout << endl;
	cout << "Khoa hoc: " << count3 << endl;
	cout << endl;
	cout << "Thieu nhi: " << count4 << endl;
	cout << endl;
	cout << "Tai lieu: " << count5 << endl;
	cout << endl;
	cout << "Giao trinh: " << count6 << endl;
	cout << endl;
}

//Thong ke theo gioi tinh
void genderquantity(reader a[], current c, int& nam, int& nu)
{
	for (int i = 0; i < c.current1; i++)
	{
		if (a[i].gender == 1)
		{
			nam++;
		}
		else if (a[i].gender == 0)
		{
			nu++;
		}
	}
}

void genderstatistic(reader a[], current c, int& nam, int& nu)
{
	genderquantity(a, c, nam, nu);
	cout << "------------------------------------------------------------\n" << endl;
	cout << "                   THONG KE \n" << endl;
	cout << "So luong doc gia nam la: " << nam << endl;
	cout << "So luong doc gia nu la: " << nu << endl;
}

//Thong ke sach dang duoc muon
void borrowed(card a, current c)
{
	int count = 0, s;
	for (int i = 0; i < c.current3; i++)
	{
		count++;
	}
	s = count - a.rcard;
	cout << "------------------------------------------------------------\n" << endl;
	cout << "                   THONG KE \n" << endl;
	cout << "So luong sach dang duoc muon: " << s << endl;
}

//Thong ke doc gia bi tre han
void overdue(reader a[], card x[], current c)
{
	cout << "------------------------------------------------------------\n" << endl;
	cout << "               DANH SACH DOC GIA TRE HAN \n" << endl;
	for (int i = 0; i < c.current3; i++)
	{
		if (DelayDays(x[i].expreturndate[0], x[i].expreturndate[1], x[i].expreturndate[2], x[i].returndate[0], x[i].returndate[1], x[i].returndate[2]) > 0)
		{
			for (int j = 0; j < c.current1; j++)
			{
				if (x[i].id2 == a[j].id)
				{
					cout << "Ma doc gia: ";
					cout << a[j].id << endl;
					cout << "Ho Ten: ";
					cout << a[j].name << endl << endl;
				}
			}
		}
		return;
	}
	cout << "Khong co doc gia nao tre han." << endl << endl;
}

//Thong ke so luong doc gia trong thu vien
void readerquantity(current c)
{
	cout << "------------------------------------------------------------\n" << endl;
	cout << "                   THONG KE \n" << endl;
	cout << "So luong doc gia: " << c.current1 << endl;
}