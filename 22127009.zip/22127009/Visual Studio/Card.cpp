#include "Card.h"
#include "Reader.h"
#include "Other.h"
#include "Book.h" 


//The muon sach 

//Luu the vao file 
void savecard(card a[], card x, current& c)
{
	ofstream in;
	in.open("card.txt");
	if (in.fail() == false)
	{
		in << c.current3 << "\n";
		for (int i = 0; i < c.current3; i++)
		{
			in << a[i].id2 << " ";
			in << a[i].expreturndate[0] << " ";
			in << a[i].expreturndate[1] << " ";
			in << a[i].expreturndate[2] << " ";
			in << a[i].borrowdate[0] << " ";
			in << a[i].borrowdate[1] << " ";
			in << a[i].borrowdate[2] << " ";
			in << a[i].returndate[0] << " ";
			in << a[i].returndate[1] << " ";
			in << a[i].returndate[2] << " ";
			in << a[i].borrowlist << " ";
		}
		in << x.rcard << "\n";
		in << endl;
	}
	in.close();
}

//Xuat the tu file
void loadcard(card a[], card x, current& c)
{
	ifstream out;
	out.open("card.txt", ios::in);
	if (out.fail() == false)
	{
		out >> c.current3;
		for (int i = 0; i < c.current3; i++)
		{
			out >> a[i].id2;
			out >> a[i].expreturndate[0];
			out >> a[i].expreturndate[1];
			out >> a[i].expreturndate[2];
			out >> a[i].borrowdate[0];
			out >> a[i].borrowdate[1];
			out >> a[i].borrowdate[2];
			out >> a[i].returndate[0];
			out >> a[i].returndate[1];
			out >> a[i].returndate[2];
			out >> a[i].borrowlist;
		}
		out >> x.rcard;
	}
	out.close();
}

//Tinh ngay tra du kien
void Expreturnday(int d, int m, int y, int& d2, int& m2, int& y2)
{

	for (int i = 1; i <= 7; i++)
	{
		d++;
		if (d > DaysOfMonth(m, y))
		{
			d = 1;
			m++;
		}
		if (d > DaysOfMonth(m, y) && m == 12)
		{
			m = 1;
			d = 1;
			y++;
		}
		else if (d2 > DaysOfMonth(m, y))
		{
			m++;
			d = 1;
		}
	}
	d2 = d;
	m2 = m;
	y2 = y;
}

//Check so luong sach truoc khi cho muon
bool checkISBN(card a[], book b[], int index)
{
	int size = 100;
	for (int i = 0; i < size; i++)
	{
		if (a[index].borrowlist == b[i].ISBN)
		{
			if (b[i].quantity > 0) return true;
			else return false;
		}
	}
	return false;
}

//Kiem tra xem co the muon sach chua
bool bcardcheck(current c, card a[], int borrowID)
{
	for (int i = 0; i < c.current3; i++)
	{
		if (borrowID == a[i].id2) return 1;
		return 0;
	}
}

//Lap the muon sach
void bcard(card a[], book b[], reader r[], current& c)
{
	int size = 100;
	int borrowID;
	cout << "------------------------------------------------------------\n";
	cout << endl;
	cout << "                   LAP PHIEU MUON SACH\n" << endl;

	cout << "(* Nhap ngay, thang, nam cach mot khoang trang *)" << endl << endl;
	cout << endl;
	cout << "Nhap ma doc gia: ";
	cin >> borrowID;
	if (bcardcheck(c, a, borrowID) == 1)
	{
		cout << "Ban da co the muon sach!" << endl;
		return;
	}
	else
	{
		if (readercheck(c, r, borrowID) == 1)
		{
			a[c.current3].id2 = borrowID;

			cout << "Nhap ngay muon: ";
			cin >> a[c.current3].borrowdate[0] >> a[c.current3].borrowdate[1] >> a[c.current3].borrowdate[2];
			CorrectDays(a[c.current3].borrowdate[0], a[c.current3].borrowdate[1], a[c.current3].borrowdate[2]);
			Expreturnday(a[c.current3].borrowdate[0], a[c.current3].borrowdate[1], a[c.current3].borrowdate[2], a[c.current3].expreturndate[0], a[c.current3].expreturndate[1], a[c.current3].expreturndate[2]);
			cout << "Ngay tra du kien: " << a[c.current3].expreturndate[0] << "/" << a[c.current3].expreturndate[1] << "/" << a[c.current3].expreturndate[2] << endl;
			cout << "Nhap ISBN sach ban can muon (4 so): ";
			cin >> a[c.current3].borrowlist;

			while (!checkISBN(a, b, c.current3))
			{
				cout << "Sach nay khong co san, vui long nhap lai: ";
				cin >> a[c.current3].borrowlist;
			}

			cout << endl;
			cout << "HOAN TAT" << endl;
			cout << endl;
			for (int i = 0; i < c.current2; i++)
			{
				if (a[c.current3].borrowlist == b[i].ISBN) b[i].quantity--;
			}
			c.current3++;
			return;
		}
		cout << "Ban chua phai la doc gia cua thu vien!\n";
		cout << endl;
	}
}

//Tinh khoang cach ngay	tre
int DelayDays(int d, int m, int y, int d2, int m2, int y2)
{
	int s, s1, s2;
	s1 = Daysfrom1(d, m, y) + DaysofYears(y);
	s2 = Daysfrom1(d2, m2, y2) + DaysofYears(y2);
	s = s2 - s1;
	return s;
}

//Tinh phi phat tra sach tre
int fine(int s)
{
	int a;
	a = 5000 * s;
	return a;
}

//The tra sach 
void rcard(card a[], book b[], reader r[], current& c, card& x)
{
	int borrowID;
	cout << "------------------------------------------------------------\n";
	cout << endl;
	cout << "                   LAP PHIEU TRA SACH \n" << endl;

	cout << "(* Nhap ngay, thang, nam cach mot khoang trang *)" << endl << endl;
	cout << "Nhap ma doc gia: ";
	cin >> borrowID;
	for (int i = 0; i < c.current3; i++)
	{
		if (borrowID == a[i].id2)
		{
			cout << "Ngay muon: " << a[i].borrowdate[0] << "/" << a[i].borrowdate[1] << "/" << a[i].borrowdate[2] << endl;
			Expreturnday(a[i].borrowdate[0], a[i].borrowdate[1], a[i].borrowdate[2], a[i].expreturndate[0], a[i].expreturndate[1], a[i].expreturndate[2]);
			cout << "Ngay tra du kien: " << a[i].expreturndate[0] << "/" << a[i].expreturndate[1] << "/" << a[i].expreturndate[2] << endl;
			cout << "ISBN sach duoc muon: ";
			cout << a[i].borrowlist << endl;
			for (int j = 0; j < c.current2; j++)
			{
				if (a[i].borrowlist == b[j].ISBN) b[j].quantity++;
			}
			cout << "Ngay tra thuc te: ";
			cin >> a[i].returndate[0] >> a[i].returndate[1] >> a[i].returndate[2];
			CorrectDays(a[i].returndate[0], a[i].returndate[1], a[i].returndate[2]);
			while (ReturnAfter(a[i].borrowdate[0], a[i].borrowdate[1], a[i].borrowdate[2], a[i].returndate[0], a[i].returndate[1], a[i].returndate[2]) == 0)
			{
				cout << "Vui long nhap lai: ";
				cin >> a[i].returndate[0] >> a[i].returndate[1] >> a[i].returndate[2];
				CorrectDays(a[i].returndate[0], a[i].returndate[1], a[i].returndate[2]);
			}
			if (DelayDays(a[i].expreturndate[0], a[i].expreturndate[1], a[i].expreturndate[2], a[i].returndate[0], a[i].returndate[1], a[i].returndate[2]) > 0)
			{
				int s = DelayDays(a[i].expreturndate[0], a[i].expreturndate[1], a[i].expreturndate[2], a[i].returndate[0], a[i].returndate[1], a[i].returndate[2]);
				x.fee = fine(s);
				cout << "Ban bi phat " << x.fee << " vi tre " << s << " ngay. \n";
				cout << endl;
			}
			x.rcard++;
			cout << "Ban co lam mat sach khong? [1.Co / 0.Khong]\n";
			bool lost;
			cin >> lost;
			if (lost)
			{
				int lfee;
				for (int j = 0; j < c.current2; j++)
				{
					if (a[i].borrowlist == b[j].ISBN)
					{
						b[j].quantity--;
						lfee = (200 * b[j].price) / 100;
					}
				}
				cout << "Ban bi phat " << lfee << " vi lam mat sach!" << endl;
			}
			cout << "HOAN TAT";
			cout << endl;
			return;
		}
	}
	cout << "Ban chua lap phieu muon sach! \n";
	cout << endl;
}


