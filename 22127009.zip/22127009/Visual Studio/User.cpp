#include "Reader.h"
#include "User.h"

//Dang nhap tai khoan
void signin(user a)
{
	cout << "Nhap ten tai khoan: \n";
	do
	{
		cin >> a.username;
		if (a.username != "hoianh1402") cout << "Tai khoan khong ton tai, hay nhap lai: \n";
		else break;
	}while(1);
	cout << "Nhap mat khau: \n";
	do 
	{
		cin >> a.password;
		if (a.password != "20012004")cout << "Sai mat khau, hay nhap lai: \n";
		else break;
	} while (1);
}