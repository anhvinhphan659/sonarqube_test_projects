#pragma once
#include "Reader.h"
#include "Other.h"

using namespace std;

struct book
{
	string bookname, author, type, publiccomp;
	int quantity, price, publicyear, ISBN;
};

void addbook(book a[], current& c);
void viewbook(book a[], current c);
void fixbook(book a[], current c);
void erasebook(book a[], current& c);
void findISBN(book a[], current c);
void findbookname(book a[], current c);
void savebook(book a[], current& c);
void loadbook(book a[], current& c);