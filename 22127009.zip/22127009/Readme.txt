Thông tin đăng nhập vào thư viện:
Username: hoianh1402
Password: 20012004

Link video demo: https://youtu.be/vynkRW0kqIU